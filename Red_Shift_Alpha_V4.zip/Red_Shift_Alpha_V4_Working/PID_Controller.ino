void PID_Controller(int base_speed, int p, int d) {

  CrossCount = 0;
  CrossDetected = false;


  while (1) {

    // portENTER_CRITICAL(&mux);
    if (ble == 1) {
      p = ble_kp;
      d = ble_kd;
      base_speed = ble_ki;
    }
    // portEXIT_CRITICAL(&mux);

    read_black_line();


    if (sumOnSensor > 0) line_position = sensorWight / sumOnSensor;
    error = center_position - line_position;


    switch (bitSensor) {
      //left side detection
      case 0b100000000000000: direction = "left"; break;
      case 0b110000000000000: direction = "left"; break;
      case 0b111000000000000: direction = "left"; break;
      case 0b111100000000000: direction = "left"; break;
      case 0b111110000000000: direction = "left"; break;
      case 0b111111000000000: direction = "left"; break;
      case 0b111111100000000: direction = "left"; break;
      case 0b111111110000000: direction = "left"; break;
      case 0b111111111000000: direction = "left"; break;
      case 0b111111111100000: direction = "left"; break;
      case 0b111111111110000: direction = "left"; break;
      case 0b111111111111000: direction = "left"; break;

      //right side detection
      case 0b000000000000001: direction = "right"; break;
      case 0b000000000000011: direction = "right"; break;
      case 0b000000000000111: direction = "right"; break;
      case 0b000000000001111: direction = "right"; break;
      case 0b000000000011111: direction = "right"; break;
      case 0b000000000111111: direction = "right"; break;
      case 0b000000001111111: direction = "right"; break;
      case 0b000000011111111: direction = "right"; break;
      case 0b000000111111111: direction = "right"; break;
      case 0b000001111111111: direction = "right"; break;
      case 0b000011111111111: direction = "right"; break;
      case 0b000111111111111: direction = "right"; break;
    }




    if (strcmp(direction, "straight") != 0) {  // direction transfer
      dir = 0;

      if (strcmp(direction, "right") == 0) {
        dir = 1;
      } else {
        dir = 2;
      }
    }



    //turn execution when all the sensor on the white surface.

    if (bitSensor == 0) {
      error = 0;

      // while(bitSensor != 0b000000000000111 || bitSensor != 0b000000000000011 || bitSensor != 0b000000000000001 || bitSensor != 0b100000000000000 || bitSensor != 0b110000000000000 || bitSensor !=  0b111000000000000)
      // {
      // Ble_motor.backward(base_speed);
      // read_black_line();
      // }
      Ble_motor.brake();
      // delay(delay_before_turn);
      // vTaskDelay(pdMS_TO_TICKS(delay_before_turn));

      if (bitSensor == 0) {
        if (strcmp(direction, "straight") != 0) {  //if the direction is either left or right
          // digitalWrite(led, HIGH);      //turning on led as indicator when left or right turn is detected.
          // delay(delay_before_turn);


          if (strcmp(direction, "right") == 0) {
            //right turn logic
            turnRight(base_speed, base_speed);
          } else {
            //left turn logic
            turnLeft(base_speed, base_speed);
          }
        }
      }
    }

    if (bitSensor == 32319 || bitSensor == 32639 || bitSensor == 32575 || bitSensor == 32703 || bitSensor == 32671 || bitSensor == 32735 || bitSensor == 32719 || bitSensor == 32543 || bitSensor == 32655 || bitSensor == 32751 || bitSensor == 32511 || bitSensor == 32255 || bitSensor == 31743 || bitSensor == 30719 || bitSensor == 32383 || bitSensor == 31999 || bitSensor == 31231 || bitSensor == 39695 || bitSensor == 31871 || bitSensor == 30975 || bitSensor == 29183)  //inverse
    {
      inverseON = !inverseON;
      digitalWrite(led_Y, inverseON);
      error = 0;
    }


    if (bitSensor == 16833 || bitSensor == 16835 || bitSensor == 16771 || bitSensor == 16577 || bitSensor == 16769 || bitSensor == 24961 || bitSensor == 24769 || bitSensor == 25025 || bitSensor == 25027 || bitSensor == 19127 || bitSensor == 32543 || bitSensor == 32383 || bitSensor == 31871 || bitSensor == 16579 || bitSensor == 24673 || bitSensor == 24769 || bitSensor == 20525 || bitSensor == 24961 || bitSensor == 25345 || bitSensor == 26369 || bitSensor == 18179

        || bitSensor == 16513 || bitSensor == 16577 || bitSensor == 24769 || bitSensor == 28897 || bitSensor == 14531 || bitSensor == 12483 || bitSensor == 28867 || bitSensor == 24963 || bitSensor == 16771 || bitSensor == 24771 || bitSensor == 248803 || bitSensor == 25475 || bitSensor == 17155 || bitSensor == 16435 || bitSensor == 24803 || bitSensor == 25478 || bitSensor == 24966 || bitSensor == 24774 || bitSensor == 12515 || bitSensor == 12675 || bitSensor == 13187 )  //Cross Section Detection
    {
      digitalWrite(Buzzer, HIGH);
      // error = 0;
    } else {
      digitalWrite(Buzzer, LOW);
    }
    // Bit_Sensor_Show();
    // Serial.print(error);

    if (bitSensor == 14350 || bitSensor == 28679 || bitSensor == 24579 || bitSensor == 16385 || bitSensor == 16387 || bitSensor == 24577 || bitSensor == 28675 || bitSensor == 16391 || bitSensor == 24583)  //T Section Detection
    {

      if (!CrossDetected) {
        CrossDetected = true;
        error = 0;

        Tsection();

        // Serial.println(CrossCount);
        CrossCount++;
      }
    } else {
      CrossDetected = false;
    }




    // /*

  // left L Detection

 if (bitSensor == 462 || bitSensor == 455 || bitSensor == 451 || bitSensor == 398 || bitSensor == 270 || bitSensor == 782 || bitSensor == 1806 || bitSensor == 1550 || bitSensor == 206 || bitSensor == 391 || bitSensor == 263 || bitSensor == 775 || bitSensor == 1799 || bitSensor == 1543 || bitSensor == 199 || bitSensor == 99 || bitSensor == 115 || bitSensor == 103 || bitSensor == 387 || bitSensor == 771 || bitSensor == 1795 || bitSensor == 1539 || bitSensor == 195
 
  // bitSensor == 223 || bitSensor == 127 || bitSensor == 255 || bitSensor == 121 || bitSensor == 496
 )   
    {

      if(!CrossDetected)
      {
      CrossDetected = true;

      Tsection();
      
      // Serial.println(CrossCount);
      
      CrossCount++;
      }

    }
    else
    {
      CrossDetected = false;
    }






    // Right L Detection

 if (bitSensor == 14784 || bitSensor == 29120 || bitSensor == 25024 || bitSensor == 31168 || bitSensor == 24960 || bitSensor == 24768 || bitSensor == 24672 || bitSensor == 28768 || bitSensor == 28864 || bitSensor == 29440 || bitSensor == 29056 || bitSensor == 30912 || bitSensor == 30816 || bitSensor == 14448 || bitSensor == 14384 || bitSensor == 24624 || bitSensor == 26368
 )   
    {

      if(!CrossDetected)
      {
      CrossDetected = true;

      Tsection();

      // Serial.println(CrossCount);
      
      CrossCount++;
      }

    }
    else
    {
      CrossDetected = false;
    }
// */








    if (bitSensor == 32767) {
      digitalWrite(Buzzer, HIGH);
      // Ble_motor.stop();
      Ble_motor.brake();
      vTaskDelay(pdMS_TO_TICKS(500));
      // delay(500);
      if (bitSensor == 32767) {
        while (1) {
          error = 0;
          stopTimmer = true;
          // stopTimer();
          Ble_motor.brake();
          digitalWrite(Buzzer, LOW);
          // pidRunning = false;
          if (pidRunning == false) {
            return;
          }
          // while (!pidRunning) pidRunning = false; return;
          // while (button(BUTTON_DOWN_PIN) == 1) pidRunning = false; return;
        }
      }
    }


    derivative = error - previous_error;
    int right_motor_correction = base_speed + (error * p + derivative * d);
    int left_motor_correction = base_speed - (error * p + derivative * d);
    previous_error = error;
    e = error;



    //Drive Motor According to PID Value
    motor(left_motor_correction, right_motor_correction);



    // showTime();
    loopFeq();
    // Serial.println("This is also running");

    // taskYIELD();
  }
}


void pid_on() {


  while (1) {
    // loopFeq();
    showTime();
    // Serial.println("Pid_Show working");

    // portENTER_CRITICAL(&mux);
    if (ble == 1) {
      Ble();
      kp = ble_kp;
      kd = ble_kd;
      base_speed = ble_ki;
      sendErrorBLE(e);
    }
    // portEXIT_CRITICAL(&mux);

    // loopFeq();
    while (stopTimmer) {
      stopTimer();
      showTime();
      while (button(BUTTON_DOWN_PIN) == 1) {
        pidRunning = false;
        return;
      }
    }
  }
}

float movingAverage(float newValue) {
  avgSum -= lineHistory[avgIndex];
  lineHistory[avgIndex] = newValue;
  avgSum += newValue;

  avgIndex++;
  if (avgIndex >= avgSize) avgIndex = 0;

  return avgSum / avgSize;
}

void showTime() {

  //Timmer

  String timerText = getTimerString();

  // Serial.println(timerText);
  u8g2.setFont(u8g2_font_profont22_tr);  // Set the font
  u8g2.firstPage();
  do {
    showDir();
    u8g2.drawStr(10, 39, timerText.c_str());
  } while (u8g2.nextPage());
}


void showDir() {


  if (dir == 0) {
    u8g2.drawXBM(60, 10, 5, 7, image_arrow_up_bits);
    // Serial.println("Forward");
  } else if (dir == 1) {
    u8g2.drawXBM(27, 12, 7, 5, image_arrow_left_bits);
    // Serial.println("left");
  } else if (dir == 2) {
    u8g2.drawXBM(93, 12, 7, 5, image_arrow_right_bits);
    // Serial.println("right");
  }
}