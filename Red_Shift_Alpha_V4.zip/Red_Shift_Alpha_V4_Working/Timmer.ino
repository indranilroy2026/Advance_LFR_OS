unsigned long stopwatchStartTime = 0;
unsigned long stoppedElapsed = 0;
bool timerRunning = false;

void startTimer() {
  stopwatchStartTime = millis();
  stoppedElapsed = 0;
  timerRunning = true;
}

void stopTimer() {
  if (timerRunning) {
    stoppedElapsed = millis() - stopwatchStartTime;
    timerRunning = false;
  }
}

void resetTimer() {
  stopwatchStartTime = 0;
  stoppedElapsed = 0;
  timerRunning = false;
}

String getTimerString() {
  unsigned long elapsed;

  if (timerRunning) {
    elapsed = millis() - stopwatchStartTime;
  } else {
    elapsed = stoppedElapsed;
  }

  unsigned int minutes = elapsed / 60000;
  unsigned int seconds = (elapsed % 60000) / 1000;
  unsigned int milliseconds = elapsed % 1000;

  char timeBuffer[16];
  sprintf(timeBuffer, "%02u:%02u:%03u", minutes, seconds, milliseconds);

  

  return String(timeBuffer);
}


void loopFeq()
{
  loopCount++;
  if(millis()-lastPrint >= 1000)
  {
    Serial.println(loopCount);
    loopCount = 0;
    lastPrint = millis();
  }
}

