void read_black_line() {
  sumOnSensor = 0;
  sensorWight = 0;
  bitSensor = 0;

  //----------------- 1st ADC --------------------
  for (int i = 0; i < 8; i++) {
    // selectChannel(i);
    // delayMicroseconds(20);

    sensorADC[i] = adc1.readADC(i);
    //map analog value
    if (sensorADC[i] < 100) {
      sensorADC[i] = 0;
    } else if (sensorADC[i] > 4000) {
      sensorADC[i] = 4096;
    }
    //analog to digital
    if (sensorADC[i] > Reference_ADC[i])
    // if (sensorADC[i] > theshold)
     {
      if (inverseON == 0) {    //black line - normal mode.
        sensorDigital[i] = 1;  //black line =1
      } else {
        sensorDigital[i] = 0;  //black line =0 (black line -inverse mode)
      }
    } else {
      if (inverseON == 0) {    //white line - normal mode
        sensorDigital[i] = 0;  //white line =0 - normal mode
      } else {
        sensorDigital[i] = 1;  //white line - inverse mode.
      }
    }
  }
//////////////////////////////////////////////////////////////

  //----------------- 2nd ADC --------------------
  for (int i = 1; i < 8; i++) {
    // selectChannel(i);
    // delayMicroseconds(20);

    sensorADC[i+7] = adc2.readADC(i-1);
    //map analog value
    if (sensorADC[i+7] < 100) {
      sensorADC[i+7] = 0;
    } else if (sensorADC[i+7] > 4000) {
      sensorADC[i+7] = 4096;
    }
    //analog to digital
    if (sensorADC[i+7] > Reference_ADC[i+7])
    // if (sensorADC[i+7] > theshold) 
    {
      if (inverseON == 0) {    //black line - normal mode.
        sensorDigital[i+7] = 1;  //black line =1
      } else {
        sensorDigital[i+7] = 0;  //black line =0 (black line -inverse mode)
      }
    } else {
      if (inverseON == 0) {    //white line - normal mode
        sensorDigital[i+7] = 0;  //white line =0 - normal mode
      } else {
        sensorDigital[i+7] = 1;  //white line - inverse mode.
      }
    }
  }
//////////////////////////////////////////////////////////////

  for (int i = 0; i < sensorNumber; i++) {
    sumOnSensor += sensorDigital[i];
    sensorWight += sensorDigital[i] * WeightValue[i];
    bitSensor += sensorDigital[i] * bitWeight[i];

    // Serial.print(String(bitRead(bitSensor, i)));
  }


  // Serial.print("  " + String(bitSensor));
  // Serial.print("  " + String(sumOnSensor) + "  " + String(sensorWight) + "  " + String(bitSensor));
  // Serial.println();
}

// void sensor_value_test() {
//   while (1) {
//     read_black_line();
//     for (int i = 0; i < sensorNumber; i++) {
//       Serial.print(String(sensorADC[i]) + "  ");
//     }
//     Serial.println();
//   }
// }

void Bit_Sensor_Show() {
  while (1) {
    read_black_line();  //take sensor reading

    Serial.print("Bit Sensor in Decimal: " + String(bitSensor));  //Decimal Value Show
    Serial.print(" | Bit Sensor in Binary: ");

    for (int i = (sensorNumber - 1); i >= 0; i--) {  //display bitsensor data in binary
      Serial.print(String(bitRead(bitSensor, i)));
    }
    Serial.println();
  }
}

// void sensor_value_check() {
//   for (int i = 0; i < sensorNumber; i++) {
//     sensorADC[i] = adc.readADC(i);
//     //map analog value
//     Serial.print(String(sensorADC[i]) + "  ");
//   }
//   for (int i = 0; i < sensorNumber; i++) {
//     //analog to digital
//     if (sensorADC[i] > theshold) {
//       sensorDigital[i] = 1;
//     } else {
//       sensorDigital[i] = 0;
//     }
//     Serial.print("  " + String(sensorDigital[i]));
//   }
//   Serial.println();
// }

//function for displaying analog value
void analog_value() {
  while (1) {
    for (int channel = 0; channel < sensorNumber; channel++) {

      if(channel<8)
        {
          sensorADC[channel] = adc1.readADC(channel);
        }
        else
        {
          sensorADC[channel] = adc2.readADC(channel-8);  // Read the analog value from the sensor
        }
    }
    u8g2.setFont(u8g2_font_profont12_tf);  // Set the font
    u8g2.firstPage();
    do {
        u8g2.setCursor(2, 52);
        u8g2.print(sensorADC[0]);

        u8g2.setCursor(2, 63);
        u8g2.print(sensorADC[1]);

        u8g2.setCursor(27, 40);
        u8g2.print(sensorADC[2]);

        u8g2.setCursor(27, 50);
        u8g2.print(sensorADC[3]);

        u8g2.setCursor(33, 30);
        u8g2.print(sensorADC[4]);

        u8g2.setCursor(40, 20);
        u8g2.print(sensorADC[5]);

        u8g2.setCursor(52, 10);
        u8g2.print(sensorADC[6]);

        u8g2.setCursor(65, 20);
        u8g2.print(sensorADC[7]);

        u8g2.setCursor(71, 30);
        u8g2.print(sensorADC[8]);

        u8g2.setCursor(77, 40);
        u8g2.print(sensorADC[9]);

        u8g2.setCursor(78, 50);
        u8g2.print(sensorADC[10]);

        u8g2.setCursor(103, 53);
        u8g2.print(sensorADC[11]);

        u8g2.setCursor(103, 63);
        u8g2.print(sensorADC[12]);



    } while (u8g2.nextPage());
    while (button(BUTTON_DOWN_PIN) == 1) return;
  }
}

//function for displaying digital value

void digital_value() {



  while (1) {
    String inverseState;
    read_black_line();

    if (bitSensor == 32319 || bitSensor == 32639 || bitSensor == 32575 || bitSensor == 32703 || bitSensor == 32671 || bitSensor == 32735 || bitSensor == 32719 || bitSensor == 32543 || bitSensor == 32655 || bitSensor == 32751 || bitSensor == 32511 || bitSensor == 32255 || bitSensor == 31743 || bitSensor == 30719 || bitSensor == 32383 || bitSensor == 31999 || bitSensor == 31231 || bitSensor == 39695 || bitSensor == 31871 || bitSensor == 30975 || bitSensor == 29183 ) {

      inverseON = !inverseON;
      digitalWrite(led_Y, inverseON);
    }

    (inverseON) ? inverseState = "Inv: ON" : inverseState = "Inv: OFF";
    u8g2.firstPage();
    do {
      u8g2.setFont(u8g2_font_profont12_tf);
      u8g2.setCursor(50, 15);
      u8g2.print(inverseState);
       
      u8g2.setCursor(8, 56);
      u8g2.print(sensorDigital[0]);

      u8g2.setCursor(10, 45);
      u8g2.print(sensorDigital[1]);

      u8g2.setCursor(19, 38);
      u8g2.print(sensorDigital[2]);

      u8g2.setCursor(28, 34);
      u8g2.print(sensorDigital[3]);

      u8g2.setCursor(37, 32);
      u8g2.print(sensorDigital[4]);

      u8g2.setCursor(45, 32);
      u8g2.print(sensorDigital[5]);

      u8g2.setCursor(53, 32);
      u8g2.print(sensorDigital[6]);

      u8g2.setCursor(61, 32);
      u8g2.print(sensorDigital[7]);

      u8g2.setCursor(69, 32);
      u8g2.print(sensorDigital[8]);

      u8g2.setCursor(77, 32);
      u8g2.print(sensorDigital[9]);

      u8g2.setCursor(85, 32);
      u8g2.print(sensorDigital[10]);

      u8g2.setCursor(94, 34);
      u8g2.print(sensorDigital[11]);

      u8g2.setCursor(102, 38);
      u8g2.print(sensorDigital[12]);

      u8g2.setCursor(110, 45);
      u8g2.print(sensorDigital[13]);

      u8g2.setCursor(112, 56);
      u8g2.print(sensorDigital[14]);




      String bitText = String(bitSensor);
      
      u8g2.setFont(u8g2_font_profont12_tf);
      u8g2.drawStr(50, 50, bitText.c_str());  //Set Bitsensor decimal value
      u8g2.setFont(u8g2_font_7x14B_tf);



      



    } while (u8g2.nextPage());
    while (button(BUTTON_DOWN_PIN) == 1) return;
  }
}

