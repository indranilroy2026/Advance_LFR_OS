#include "MotorDriver.h"

void MotorDriver::begin(
  uint8_t standby,
  uint8_t pwmA,
  uint8_t ain1,
  uint8_t ain2,
  uint8_t pwmB,
  uint8_t bin1,
  uint8_t bin2
) {
  // Store pin config (CORRECT)
  this->standby = standby;
  pwm_A = pwmA;
  Ain_B = ain1;
  Ain_F = ain2;
  pwm_B = pwmB;
  Bin_F = bin1;
  Bin_B = bin2;

  pinMode(this->standby, OUTPUT);

  pinMode(pwm_A, OUTPUT);
  pinMode(Ain_B, OUTPUT);
  pinMode(Ain_F, OUTPUT);

  pinMode(pwm_B, OUTPUT);
  pinMode(Bin_F, OUTPUT);
  pinMode(Bin_B, OUTPUT);

  // Engine enabled by default
  E = true;
  digitalWrite(this->standby, HIGH);
}

// ---------------- MOVEMENT ----------------

void MotorDriver::forward(uint8_t speed) {
  digitalWrite(this->standby, E);

  digitalWrite(Ain_F, HIGH);
  digitalWrite(Ain_B, LOW);
  digitalWrite(Bin_F, HIGH);
  digitalWrite(Bin_B, LOW);


  analogWrite(pwm_A, speed);
  analogWrite(pwm_B, speed);
}

void MotorDriver::backward(uint8_t speed) {
  digitalWrite(this->standby, E);

  digitalWrite(Ain_F, LOW);
  digitalWrite(Ain_B, HIGH);
  digitalWrite(Bin_F, LOW);
  digitalWrite(Bin_B, HIGH);

  analogWrite(pwm_A, speed);
  analogWrite(pwm_B, speed);
}

void MotorDriver::left(uint8_t speed) {
  digitalWrite(this->standby, E);

  digitalWrite(Ain_B, LOW);
  digitalWrite(Ain_F, HIGH);
  digitalWrite(Bin_F, LOW);
  digitalWrite(Bin_B, HIGH);

  analogWrite(pwm_A, speed);
  analogWrite(pwm_B, speed);
}

void MotorDriver::right(uint8_t speed) {
  digitalWrite(this->standby, E);

  digitalWrite(Ain_B, HIGH);
  digitalWrite(Ain_F, LOW);
  digitalWrite(Bin_F, HIGH);
  digitalWrite(Bin_B, LOW);

  analogWrite(pwm_A, speed);
  analogWrite(pwm_B, speed);
}

void MotorDriver::stop() {
  digitalWrite(this->standby, E);

  digitalWrite(Ain_B, LOW);
  digitalWrite(Ain_F, LOW);
  digitalWrite(Bin_F, LOW);
  digitalWrite(Bin_B, LOW);

  analogWrite(pwm_A, 0);
  analogWrite(pwm_B, 0);
}

void MotorDriver::brake() {
  digitalWrite(this->standby, E);

  digitalWrite(Ain_B, HIGH);
  digitalWrite(Ain_F, HIGH);
  digitalWrite(Bin_F, HIGH);
  digitalWrite(Bin_B, HIGH);

  analogWrite(pwm_A, 0);
  analogWrite(pwm_B, 0);
}

// ---------------- ENGINE TOGGLE ----------------

void MotorDriver::enable() {
  E = true;
  digitalWrite(this->standby, HIGH);
}

void MotorDriver::disable() {
  E = false;
  digitalWrite(this->standby, LOW);
}
