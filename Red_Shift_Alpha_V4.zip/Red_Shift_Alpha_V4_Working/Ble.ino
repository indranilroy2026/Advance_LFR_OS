BLECharacteristic *pCharacteristic;

int connection;
bool commandReady = false;
String receivedCommand = "";
// 🔹 When data is received from phone
class CharacteristicCallbacks : public BLECharacteristicCallbacks {
  void onWrite(BLECharacteristic *pChar) {

    String value = pChar->getValue().c_str();
    value.trim();

    if (value.length() == 0) return;

    receivedCommand = value;
    commandReady = true;
  }
  
};

// 🔹 BLE disconnect safety
class ServerCallbacks : public BLEServerCallbacks {
  void onDisconnect(BLEServer* server) {
    connection = 0;
    Serial.println("Device disconnected");
    BLEDevice::startAdvertising();
    
  }

  void onConnect(BLEServer* server) {
    connection = 1;
    Serial.println("Device connected");
    
  }
};

  // Start Ble

void BleOn() 
{
  BLEDevice::init("RED_SHIFT");

  BLEServer *server = BLEDevice::createServer();
  server->setCallbacks(new ServerCallbacks());

  BLEService *service = server->createService(SERVICE_UUID);

  pCharacteristic = service->createCharacteristic(
                      CHARACTERISTIC_UUID,
                      BLECharacteristic::PROPERTY_READ |
                      BLECharacteristic::PROPERTY_WRITE |
                      BLECharacteristic::PROPERTY_NOTIFY
                    );

  pCharacteristic->addDescriptor(new BLE2902());
  pCharacteristic->setCallbacks(new CharacteristicCallbacks());

  service->start();
  BLEDevice::startAdvertising();
}








void Ble() {

  if (commandReady) {

    Serial.print("Received → ");
    Serial.println(receivedCommand);

    String cmd = String(receivedCommand);

      // -------- ENGINE TOGGLE --------
      if (cmd == "E") {
        Ble_motor.enable();
        engineEnabled = true;
        return;
      }

      if (cmd == "e") {
        Ble_motor.disable();
        engineEnabled = false;
        return;
      }

          // -------- SPEED --------
      if (cmd.startsWith("SPD")) {
        int idx = cmd.indexOf(':');
        if (idx == -1) idx = cmd.indexOf('=');

        if (idx != -1) {
          base_speed = constrain(cmd.substring(idx + 1).toInt(), 0, 255);
        }
        return;
      }


      // -------- BLOCK MOVEMENT IF ENGINE OFF --------
      if (!engineEnabled) {
        if (cmd == "B") Ble_motor.brake();
        if (cmd == "X") Ble_motor.stop();
        return;
      }

      // -------- CLEAN SWITCH (AS YOU WANTED) --------
      switch (cmd.charAt(0)) {
        case 'W': Ble_motor.forward(base_speed); break;
        case 'S': Ble_motor.backward(base_speed); break;
        case 'A': Ble_motor.left(base_speed); break;
        case 'D': Ble_motor.right(base_speed); break;

        case 'B': Ble_motor.brake(); break;
        case 'X': Ble_motor.stop(); break;
        default: break;
      }

    //     Serial.print("Received → ");
    // Serial.println(String(receivedCommand));

    


    int commaIndex = receivedCommand.indexOf(',');

    if (commaIndex != -1) {

      String key = receivedCommand.substring(0, commaIndex);
      String valueStr = receivedCommand.substring(commaIndex + 1);
      key.trim();
      valueStr.trim();

      float value = valueStr.toFloat();

      if (key == "kp") {
        ble_kp = value;
        kp = ble_kp;

        // Serial.println("KP updated");
      }
      else if (key == "ki") {
        ble_ki = value;
        // Serial.println("KI updated");
      }
      else if (key == "kd") {
        ble_kd = value;
        kd = ble_kd;

        // Serial.println("KD updated");s
      }
      else {
        // Serial.println("Unknown command");
      }

      // Serial.println("------ CURRENT PID ------");
      // Serial.print("KP: "); Serial.println(ble_kp);
      // Serial.print("KD: "); Serial.println(ble_kd);
      // Serial.println("-------------------------");

    commandReady = false;
    }
  }
}


void sendErrorBLE(float errorValue) {
  char buffer[30];
  snprintf(buffer, sizeof(buffer), "ERR: %.2f", errorValue);
  pCharacteristic->setValue(buffer);
  pCharacteristic->notify();
  
  // Serial.print("send → ");
  // Serial.println(buffer);
}