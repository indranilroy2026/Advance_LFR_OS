bool center()
{
  if(sensorDigital[3] == 1 || sensorDigital[7] == 1 || sensorDigital[11] == 1)
  {
    return false;
  }
  return true;
}
void turnRight(int L, int R) {
  //   while(sensorDigital[3] != 1){
  //   motor(-L, R);
  //   read_black_line();
  //   showTime(); 
  // }
  error = 0;
  // vTaskDelay(pdMS_TO_TICKS(delay_before_turn));

  while (center()) {  //loop will break when sensor number 4 detects line.
    Ble_motor.left(turnSpeed);                  //right motor forward and left motor backward.
    read_black_line();
    // showTime();            
  }
    direction = "straight";       //set the direction value to default
}

void turnLeft(int L, int R) {
  // while(sensorDigital[11] != 1){
  //   motor(L, -R);
  //   read_black_line();
  //   showTime(); 
  // }
  error = 0;
  // vTaskDelay(pdMS_TO_TICKS(delay_before_turn));
  
  while (center()) {  //loop will break when sensor number 4 detects line.
    Ble_motor.right(turnSpeed);                  //right motor forward and left motor backward.
    read_black_line();  
    // showTime();           
  }
    direction = "straight";        //set the direction value to default
}

void hard_stop() {
  while (1) motor(0, 0);
}
void stop() {
  digitalWrite(right_motor_forward, HIGH);
  digitalWrite(right_motor_backward, HIGH);
  digitalWrite(left_motor_forward, HIGH);
  digitalWrite(left_motor_backward, HIGH);

  motor(0, 0);
}

void distance_calibration(uint16_t test_time) {
  unsigned long startTime = millis();
  while (millis() - startTime < test_time) {
    motor(base_speed, base_speed);  //forward movement
  }
  motor(0, 0);  //stop after completing the measured distance.
}

void distance(uint16_t dist) {
  int time_per_cm = test_time / measured_distance;
  unsigned long moveTime = dist * time_per_cm;
  unsigned long startTime = millis();

  while (millis() - startTime < moveTime) {
    motor(base_speed, base_speed);  //forward movement
  }
}
