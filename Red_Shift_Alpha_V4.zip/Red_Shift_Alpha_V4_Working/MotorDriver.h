#ifndef MOTORDRIVER_H
#define MOTORDRIVER_H

#include <Arduino.h>

class MotorDriver {
public:
  void begin(
    uint8_t standby,
    uint8_t pwmA,
    uint8_t ain1,
    uint8_t ain2,
    uint8_t pwmB,
    uint8_t bin1,
    uint8_t bin2
  );

  void forward(uint8_t speed);
  void backward(uint8_t speed);
  void left(uint8_t speed);
  void right(uint8_t speed);
  void stop();

  void enable();
  void disable();
  void brake();
  




private:
  bool E;
  uint8_t standby;
  uint8_t pwm_A;
  uint8_t Ain_F;
  uint8_t Ain_B;
  uint8_t pwm_B;
  uint8_t Bin_F;
  uint8_t Bin_B;
};

#endif
