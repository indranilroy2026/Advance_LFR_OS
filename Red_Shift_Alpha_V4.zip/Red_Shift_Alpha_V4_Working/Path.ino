


void Tsection() {
  const char* TsectionArr[] = {
    "right"
    ,"straight"
    ,"right"
    ,"straight"
    ,"right"
    ,"straight"
    ,"right"
    ,"right"
  };

  int size = sizeof(TsectionArr) / sizeof(TsectionArr[0]);

  if (CrossCount > size) {
    direction = "left";  // fallback
  } else {
    direction = TsectionArr[CrossCount];
  }

  if (strcmp(direction, "straight") == 0)
      {
        dir = 0;
        Ble_motor.forward(base_speed);
        vTaskDelay(pdMS_TO_TICKS(100));
      }
      else if (strcmp(direction, "left") == 0)
      {
        dir = 2;
        turnRight(base_speed, base_speed);
      }
      else
      {
        dir = 1;
        turnLeft(base_speed, base_speed);
      }
}