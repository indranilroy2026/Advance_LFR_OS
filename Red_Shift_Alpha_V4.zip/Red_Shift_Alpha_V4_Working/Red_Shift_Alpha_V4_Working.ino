#include <U8g2lib.h>
#include <Wire.h>
#include <MUIU8g2.h>
#include <U8x8lib.h>


#include <string.h>



// BLE
#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLEUtils.h>
#include <BLE2902.h>

#define SERVICE_UUID        "4fafc201-1fb5-459e-8fcc-c5c9c331914b"
#define CHARACTERISTIC_UUID "beb5483e-36e1-4688-b7f5-ea07361b26a8"


// PID values
volatile float ble_kp = 0;
volatile float ble_ki = 0;
volatile float ble_kd = 0;



/*
---------------------------------------------
𝑬-𝒎𝒂𝒊𝒍: aslamhshakil20@gmail.com
𝑭𝒂𝒄𝒆𝒃𝒐𝒐𝒌: https://www.facebook.com/RoboTechInnovator/
𝑾𝒉𝒂𝒕'𝒔 𝑨𝒑𝒑: https://wa.me/c/8801647467658 (Get the LFR Kit and Components)
Instagram: https://www.instagram.com/robotech_innovator?igsh=aXk4Z2JrZHc4NjJu
*/

// u8g2LIB_SSD1306_128X64 u8g2(u8g2_I2C_OPT_DEV_0 | u8g2_I2C_OPT_NO_ACK | u8g2_I2C_OPT_FAST);  // Fast I2C / TWI
// u8g2LIB_SSD1306_128X64 u8g2(13, 11, 8, 9, 10); // SPI connection
// for I2C connection, use this wiring:
// GND > GND
// VCC > 3.3V
// SCL > A5
// SDA > A4


U8G2_SSD1306_128X64_NONAME_F_HW_I2C u8g2(U8G2_R0, /* reset=*/ U8X8_PIN_NONE);



#include <EEPROM.h>
#include <MCP3208.h>

#define MCP1_CS 5
#define MCP2_CS 17

MCP3208 adc1;
MCP3208 adc2;

#include "MotorDriver.h"
MotorDriver Ble_motor;

//motorpins
#define right_motor_backward 14  //IN2(L298) || TB6612 -- AIN1
#define right_motor_forward 12  //IN1(L298) || TB6612 -- AIN2
#define left_motor_forward 25    //IN3(L298)  || TB6612 --- BIN1
#define left_motor_backward 26   //IN4(L298)  || TB6612 --- BIN2
//speed control pins (PWM)
#define right_motor_speed 13  //EnA (L298) //TB6612 --- PWMA
#define left_motor_speed 33   //EnB (L298) //TB6612 --- PWMB

#define Stand_by 27

//button pins
#define BUTTON_UP_PIN 36      // pin for UP button
#define BUTTON_SELECT_PIN 39  // pin for SELECT button
#define BUTTON_DOWN_PIN 34    // pin for DOWN button

//Leds
#define led_Y 2
#define led_G 4
#define led_B 16

//Sensor Variables
#define sensorNumber 15
int sensorADC[sensorNumber];
int sensorDigital[sensorNumber];
int bitWeight[sensorNumber] = { 1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048, 4096, 8192, 16384};
int WeightValue[sensorNumber] = {10, 20, 30, 40, 50, 60, 70, 80,  90, 100, 110, 120, 130, 140, 150};
int theshold = 150;
int sumOnSensor;
int sensorWight;
int bitSensor;
int Max_ADC[sensorNumber];
int Min_ADC[sensorNumber];
int Reference_ADC[sensorNumber];


//PID Variables
float line_position;
float error;
float center_position = 80;
float derivative, previous_error;
bool engineEnabled = true;
int base_speed = 230;
int kp = 11;
int kd = 220;

//turns variable
const char* direction = "straight";  //default value straight
#define delay_before_turn 100
#define turnSpeed 100
//timers
#define stop_time 20
//inverse parameter
bool inverseON = 0;   //0 = normal line, 1 = inverse line

//distance calibration parameters
uint16_t test_time = 500;  //need to be adjusted for measured distance
int measured_distance = 30;
//led
#define Buzzer 15




int CrossCount = 0;
bool CrossDetected = false;

volatile bool ble = 0;

const int avgSize = 5;
float lineHistory[avgSize] = {0};
int avgIndex = 0;
float avgSum = 0;

unsigned long lastPrint = 0;
unsigned long loopCount = 0;

volatile bool pidRunning = false;
volatile bool stopTimmer = false;
volatile int dir= 0;
volatile int e= 0;


portMUX_TYPE mux = portMUX_INITIALIZER_UNLOCKED;




const unsigned char upir_logo[] PROGMEM = {  // this is another way how to define images, using binary notation
  B00010101, B11010111,
  B00010101, B01000101,
  B00010101, B10010110,
  B00011001, B00010101
};

// 'scrollbar_background', 8x64px
const unsigned char bitmap_scrollbar_background[] PROGMEM = {
  0x00, 0x02, 0x00, 0x02, 0x00, 0x02, 0x00, 0x02, 0x00, 0x02, 0x00, 0x02, 0x00, 0x02, 0x00, 0x02,
  0x00, 0x02, 0x00, 0x02, 0x00, 0x02, 0x00, 0x02, 0x00, 0x02, 0x00, 0x02, 0x00, 0x02, 0x00, 0x02,
  0x00, 0x02, 0x00, 0x02, 0x00, 0x02, 0x00, 0x02, 0x00, 0x02, 0x00, 0x02, 0x00, 0x02, 0x00, 0x02,
  0x00, 0x02, 0x00, 0x02, 0x00, 0x02, 0x00, 0x02, 0x00, 0x02, 0x00, 0x02, 0x00, 0x02, 0x00, 0x00
};
// 'item_sel_outline', 128x21px
const unsigned char bitmap_item_sel_outline[] PROGMEM = {
  0x1f, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xc0,
  0x20, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x20,
  0x40, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x30,
  0x40, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x30,
  0x40, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x30,
  0x40, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x30,
  0x40, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x30,
  0x40, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x30,
  0x40, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x30,
  0x40, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x30,
  0x40, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x30,
  0x40, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x30,
  0x40, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x30,
  0x40, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x30,
  0x40, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x30,
  0x40, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x30,
  0x40, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x30,
  0x40, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x30,
  0x40, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x30,
  0x3f, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xe0,
  0x1f, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xc0
};


static const unsigned char image_arrow_left_bits[] = {0x04,0x02,0x7f,0x02,0x04};
static const unsigned char image_arrow_right_bits[] = {0x10,0x20,0x7f,0x20,0x10};
static const unsigned char image_arrow_up_bits[] = {0x04,0x0e,0x15,0x04,0x04,0x04,0x04};
  

// ------------------ end generated bitmaps from image2cpp ---------------------------------
const int NUM_ITEMS = 6;         // number of items in the list and also the number of screenshots and screenshots with QR codes (other screens)
const int MAX_ITEM_LENGTH = 20;  // maximum characters for the item name

char menu_items[NUM_ITEMS][MAX_ITEM_LENGTH] = {
  // array with item names
  { "Line Follow" },
  { "Calibration" },
  { "Analog Value" },
  { "Digital Value" },
  { "Motor Test" },
  { "Bluetooth" },
};
// note - when changing the order of items above, make sure the other arrays referencing bitmaps
// also have the same order, for example array "bitmap_icons" for icons, and other arrays for screenshots and QR codes
int button_up_clicked = 0;      // only perform action when button is clicked, and wait until another press
int button_select_clicked = 0;  // same as above
int button_down_clicked = 0;    // same as above
int item_selected = 0;          // which item in the menu is selected
int item_sel_previous;          // previous item - used in the menu screen to draw the item before the selected one
int item_sel_next;              // next item - used in the menu screen to draw next item after the selected one
int current_screen = 0;         // 0 = menu, 1 = screenshot, 2 = qr


//************************************SETUP***************************************
void setup() {
  Serial.begin(115200);
  Wire.begin(21, 22);
  u8g2.begin();

  adc1.begin(MCP1_CS);    // MCP3208 #1
  adc2.begin(MCP2_CS);    // MCP3208 #2
  u8g2.setColorIndex(1);  // set the color to white
  pinMode(BUTTON_UP_PIN, INPUT);
  pinMode(BUTTON_DOWN_PIN, INPUT);
  pinMode(BUTTON_SELECT_PIN, INPUT);

  pinMode(led_Y, OUTPUT);
  pinMode(led_G, OUTPUT);
  pinMode(led_B, OUTPUT);

  pinMode(Buzzer, OUTPUT);


  Ble_motor.begin
  (
    Stand_by, // standby
    right_motor_speed, // pwm A
    right_motor_backward, // Ain1
    right_motor_forward, // Ain2
    left_motor_speed, // pwm B
    left_motor_forward, // Bin1
    left_motor_backward  // Bin2
  );

  pinMode(left_motor_forward, OUTPUT);
  pinMode(left_motor_backward, OUTPUT);
  pinMode(right_motor_forward, OUTPUT);
  pinMode(right_motor_backward, OUTPUT);
  pinMode(Stand_by, OUTPUT);

  pinMode(left_motor_speed, OUTPUT);
  pinMode(left_motor_speed, OUTPUT);

  EEPROM.begin(512);
  LoadCalibration();  //load calibration value from eeprom whenever the arduino is start or reset
  digitalWrite(Stand_by, HIGH);



  xTaskCreatePinnedToCore(
    PID_Task,        // function
    "PID Task",      // name
    10000,           // stack size
    NULL,
    0,               // priority
    NULL,
    0                // CORE 0
  );


}


//************************************LOOPS***************************************

void PID_Task(void *pvParameters) {       //core 0
  while (true) {

    if (pidRunning) {  // PID is ACTIVE

      PID_Controller(base_speed, kp, kd);

    }
    // PID_Controller(int base_speed, int p, int d);
    // vTaskDelay(1); // very small delay (important)
  }
  taskYIELD();
}

void loop() {     //Core 1
  //front page
  while (1) {
    read_black_line();

    Ble();
    // Bit_Sensor_Show();
      
    // Serial.print("KP: "); Serial.print(kp);
    // Serial.print("\t KD: "); Serial.println(kd);


    u8g2.firstPage();
    do {
      u8g2.setFont(u8g2_font_7x14B_tf);
      u8g2.drawStr(33, 15, "RED SHIFT");  //Set Your Team Name
      //
      u8g2.setFont(u8g2_font_profont12_tf);
      u8g2.drawStr(38, 60, "Red Shift");  //Set Your Bot Name
      u8g2.setFont(u8g2_font_7x14B_tf);


      u8g2.setCursor(8, 56);
      u8g2.print(sensorDigital[0]);

      u8g2.setCursor(10, 45);
      u8g2.print(sensorDigital[1]);

      u8g2.setCursor(19, 38);
      u8g2.print(sensorDigital[2]);

      u8g2.setCursor(28, 34);
      u8g2.print(sensorDigital[3]);

      u8g2.setCursor(37, 32);
      u8g2.print(sensorDigital[4]);

      u8g2.setCursor(45, 32);
      u8g2.print(sensorDigital[5]);

      u8g2.setCursor(53, 32);
      u8g2.print(sensorDigital[6]);

      u8g2.setCursor(61, 32);
      u8g2.print(sensorDigital[7]);

      u8g2.setCursor(69, 32);
      u8g2.print(sensorDigital[8]);

      u8g2.setCursor(77, 32);
      u8g2.print(sensorDigital[9]);

      u8g2.setCursor(85, 32);
      u8g2.print(sensorDigital[10]);

      u8g2.setCursor(94, 34);
      u8g2.print(sensorDigital[11]);

      u8g2.setCursor(102, 38);
      u8g2.print(sensorDigital[12]);

      u8g2.setCursor(110, 45);
      u8g2.print(sensorDigital[13]);

      u8g2.setCursor(112, 56);
      u8g2.print(sensorDigital[14]);

    } while (u8g2.nextPage());
    while (button(BUTTON_DOWN_PIN) == 1) menu(); 
    // loopFeq();
  }
}
