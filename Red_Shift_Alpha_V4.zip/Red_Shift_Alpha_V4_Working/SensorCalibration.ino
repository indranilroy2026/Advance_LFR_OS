void calibrateSensor() {
  u8g2.setFont(u8g2_font_7x14B_tf);  // Set the font
  u8g2.firstPage();
  do {
    u8g2.drawStr(5, 35, "Calibrating...");
  } while (u8g2.nextPage());
  // Initialize calibration limits
  for (int i = 0; i < sensorNumber; i++) {
    Max_ADC[i] = 0;     // Set the maximum ADC value for each sensor to 0 (lowest possible)
    Min_ADC[i] = 4000;  // Set the minimum ADC value for each sensor to 1024 (highest possible, since ADC range is 0–1023)
  }
  // Define rotation directions for calibration sweeps
  int rotationDirections[][2] = {
    { -1, 1 },  // Rotate robot slightly to the left
    { 1, -1 },  // Rotate robot slightly to the right
    { 1, -1 },  // Repeat rotation to the right for better calibration coverage
    { -1, 1 }   // Rotate left again to cover the full sensor range
  };
  digitalWrite(led_Y,HIGH);

  // Perform calibration sweeps (4 passes)
  for (int step = 0; step < 4; step++) {
    // Rotate the robot slowly in the defined direction for this step
    motor(base_speed * 1 * rotationDirections[step][0],
          base_speed * 1 * rotationDirections[step][1]);

    // Sweep through several readings while rotating
    for (int sweep = 0; sweep < 500; sweep++) {
      // Read each sensor one by one
      for (int i = 0; i < sensorNumber; i++) {
        if(i<8)
        {
          sensorADC[i] = adc1.readADC(i);
        }
        else
        {
          sensorADC[i] = adc2.readADC(i-8);  // Read the analog value from the sensor
        }
        // Update the maximum and minimum ADC values recorded for this sensor
        Max_ADC[i] = max(Max_ADC[i], sensorADC[i]);
        Min_ADC[i] = min(Min_ADC[i], sensorADC[i]);
      }
    }  
    motor(0, 0);  // Stop the motors after each rotation step
    delay(200);   // Small pause before changing rotation direction
  }

  digitalWrite(led_Y,LOW);  
 digitalWrite(led_Y,HIGH);


//-------------Save to EEPROM---------------

  int addr = 0;

  for (int i = 0; i < sensorNumber; i++) {

    Reference_ADC[i] = (Max_ADC[i] + Min_ADC[i]) / 9.0;       // Calculate mid-point (reference) value
    
    // theshold += Reference_ADC[i];

    EEPROM.put(addr, Reference_ADC[i]);
    addr += sizeof(Reference_ADC[i]);

    EEPROM.put(addr, Max_ADC[i]);
    addr += sizeof(Max_ADC[i]);

    EEPROM.put(addr, Min_ADC[i]);
    addr += sizeof(Min_ADC[i]);
  }

  // theshold /= 2;

  // EEPROM.put(addr, theshold);     //mid of all
  // addr += sizeof(theshold);

  EEPROM.commit();








  // // Store calibrated Reference, Max, and Min values in EEPROM
  // for (int i = 0; i < sensorNumber; i++) {
  //   Reference_ADC[i] = (Max_ADC[i] + Min_ADC[i]) / 2.0;  // Calculate mid-point (reference) value

  //   EEPROM.write(i, Reference_ADC[i] / 4);           // Store reference value (divided by 4 because EEPROM stores 0–255)
  //   delay(5);                                        // Small delay for EEPROM write stability
  //   EEPROM.write(i + sensorNumber, Max_ADC[i] / 4);  // Store maximum calibrated value
  //   delay(5);
  //   EEPROM.write(i + (sensorNumber * 2), Min_ADC[i] / 4);  // Store minimum calibrated value
  //   delay(5);
  // }






  digitalWrite(led_Y,LOW);
  show_calibration();
    
}

// Function to load calibration data from EEPROM
void LoadCalibration() {




//-------------Load from EEPROM---------------

int addr = 0;

  for (int i = 0; i < sensorNumber; i++) {
    EEPROM.get(addr, Reference_ADC[i]);
    addr += sizeof(Reference_ADC[i]);

    EEPROM.get(addr, Max_ADC[i]);
    addr += sizeof(Max_ADC[i]);

    EEPROM.get(addr, Min_ADC[i]);
    addr += sizeof(Min_ADC[i]);

    Serial.print(Reference_ADC[i]);
    Serial.print(", ");
    
  }

  // EEPROM.get(addr, theshold);     //mid of all
  // addr += sizeof(theshold);

  Serial.println();
  Serial.println(theshold);
  






//   // Print header labels for serial monitor (sensor indices)

//   // Load the stored calibration data for each sensor
//   for (int i = 0; i < sensorNumber; i++) {
//     Reference_ADC[i] = EEPROM.read(i) * 4;                 // Read and restore reference value
//     Max_ADC[i] = EEPROM.read(i + sensorNumber) * 4;        // Read and restore maximum value
//     Min_ADC[i] = EEPROM.read(i + (sensorNumber * 2)) * 4;  // Read and restore minimum value

//     Serial.print(String(Reference_ADC[i]) + ",  ");  // Print loaded reference value
//   }
//   Serial.println();  // Move to new line after printing all sensor values







}








//function for displaying calibration value
void show_calibration() {
  while (1) {
    // Set the font
    u8g2.firstPage();
    do {
      //title print
      u8g2.setFont(u8g2_font_7x14B_tf);
      u8g2.drawStr(15, 10, "MIN");
      u8g2.drawStr(55, 10, "MID");
      u8g2.drawStr(95, 10, "MAX");
      //value print
      u8g2.setFont(u8g2_font_profont12_tf);
      u8g2.setCursor(15, 30);
      u8g2.print(Min_ADC[0]);
      u8g2.setCursor(15, 45);
      u8g2.print(Min_ADC[7]);
      u8g2.setCursor(15, 60);
      u8g2.print(Min_ADC[14]);
      //
      u8g2.setFont(u8g2_font_profont12_tf);
      u8g2.setCursor(55, 30);
      u8g2.print(Reference_ADC[0]);
      u8g2.setCursor(55, 45);
      u8g2.print(Reference_ADC[7]);
      u8g2.setCursor(55, 60);
      u8g2.print(Reference_ADC[14]);
      //
      u8g2.setFont(u8g2_font_profont12_tf);
      u8g2.setCursor(95, 30);
      u8g2.print(Max_ADC[0]);
      u8g2.setCursor(95, 45);
      u8g2.print(Max_ADC[7]);
      u8g2.setCursor(95, 60);
      u8g2.print(Max_ADC[14]);
    } while (u8g2.nextPage());
    while (button(BUTTON_DOWN_PIN) == 1) return menu();
  }
}
